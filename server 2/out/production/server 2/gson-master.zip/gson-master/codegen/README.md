# codegen

This Maven module contains the source code for automatically generating Gson type adapters.

:warning: This module is currently non-functional and might be removed in the future.
